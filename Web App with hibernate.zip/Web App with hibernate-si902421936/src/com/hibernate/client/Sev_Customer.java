package com.hibernate.client;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.entity.Account;
import com.hibernate.entity.Address;
import com.hibernate.entity.Customer;
import com.hibernate.entity.Demat;
import com.hibernate.entity.Joint;
import com.hibernate.entity.Saving;
import com.hibernate.utility.HibernateUtility;

/**
 * Servlet implementation class Customer
 */
@WebServlet("/Sev_Customer")
public class Sev_Customer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Sev_Customer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("cname");
		String co_Holder=request.getParameter("co_name");
		String address=request.getParameter("addr");
		String acc=request.getParameter("select");
		Double balance=Double.parseDouble(request.getParameter("num"));
		
		SessionFactory	factory=HibernateUtility.obtainSessionFactory();
		Session	session=factory.getCurrentSession();
	    Transaction	txn=session.beginTransaction();
	    
	    Customer c=new Customer(name, balance,new Address(address));
		Account a=null;
		int minBal=0;
		switch(acc)
		{
		 case "Saving":
             a = new Saving();
             minBal=1000;
             break;
		case "Joint":
			a=new Joint();
			c.setCo_Holder(co_Holder);
			minBal=5000;
			break;
		case "Demat":
            a = new Demat();
            minBal=0;
            break;
        default:
            response.getWriter().println("Invalid account type selected.");
            return;
		}
		
		if(balance<minBal){
			response.getWriter().println("<h2>"+"Account Creation Failed."+"</h2>");
			response.getWriter().println("<h1>"+"Minimum Balance for "+acc+" Account is "+minBal+
					"</h1>");
			response.getWriter().println("<h1>"+"Please Enter Valid Amount"+"</h1>");
			response.getWriter().println("<a href='View.html'>Go Back</a>");
		}
		else{
			c.setAcc(a);
			a.setCustomer(c);
			
			session.save(c);
			txn.commit();
		response.getWriter().println("<h2>"+"Account Has been created succesfully...!"+"</h2>");
		response.getWriter().println("Customer Id:"+c.getCust_id()+"<br>");
		response.getWriter().println("Account Id:"+c.getAcc().getAccid()+"<br>");
		switch(acc)
		{
		 case "Saving":
             response.getWriter().println("Rate Of Interest:"+c.getAcc().getRateofInterest()+"%"+"<br>");
             break;
		case "Joint":
			response.getWriter().println("Rate Of Interest:"+c.getAcc().getRateofInterest()+"%"+"<br>");
			break;
		case "Demat":
            response.getWriter().println("Monthly Charges:"+c.getAcc().getMonthlycharges()+"Rs"+"<br>");
            break;
        default:
            response.getWriter().println("Invalid.");
            return;
		}
	}
	}
}
