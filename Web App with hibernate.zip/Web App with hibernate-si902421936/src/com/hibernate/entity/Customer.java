package com.hibernate.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="customer")
public class Customer {
	
	@Id
    @GenericGenerator(name = "name-based-id", strategy = "com.hibernate.entity.Alphanumeric_Id") // Use your actual package name
    @GeneratedValue(generator = "name-based-id")
	private String cust_id;
	
	@Column(length=20)
	private String name;
	
	@Column
	private Double balance;
	
	@Column
	private String co_Holder;
	
	@Embedded
	Address reAddress;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="accid")
	private Account acc;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Address getReAddress() {
		return reAddress;
	}

	public void setReAddress(Address reAddress) {
		this.reAddress = reAddress;
	}

	public Account getAcc() {
		return acc;
	}

	public void setAcc(Account acc) {
		this.acc = acc;
	}

	public Customer() {
		super();
	}
	
	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}


	public String getCo_Holder() {
		return co_Holder;
	}

	public void setCo_Holder(String co_Holder) {
		this.co_Holder = co_Holder;
	}

	public Customer(String name, Double balance, Address reAddress) {
		super();
		this.name = name;
		this.balance = balance;
		this.reAddress = reAddress;
	}

	@Override
	public String toString() {
		return "Customer [cust_id=" + cust_id + ", name=" + name + ", balance=" + balance + ", reAddress=" + reAddress
				+ ", acc=" + acc + "]";
	}


}
