package com.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="joint_account")

@PrimaryKeyJoinColumn(name="j_acc_id")
public class Joint extends Account{
	@Column(name="rate_of_interest")
	private final float rtf=0.3f;
	
	@Override
	public String toString() {
		return "Joint [rtf=" + rtf + "]";
	}
	
	@Override
	public float getRateofInterest() {
		
		return 0.3f;
	}
		
}
