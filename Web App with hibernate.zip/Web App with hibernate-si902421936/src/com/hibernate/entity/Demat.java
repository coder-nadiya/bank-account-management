package com.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="demat_account")

@PrimaryKeyJoinColumn(name="d_acc_id")
public class Demat extends Account{
	@Column(name="monthly_charges")
	private final float charges=0.0f;

	@Override
	public String toString() {
		return "Demate [charges=" + charges + "]";
	}

	@Override
	public float getMonthlycharges() {
		return 150.0f;
	}
	
}
