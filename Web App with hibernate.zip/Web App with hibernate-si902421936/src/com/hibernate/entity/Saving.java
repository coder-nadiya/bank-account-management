package com.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="saving_account")

@PrimaryKeyJoinColumn(name="s_acc_id")
public class Saving extends Account{
	@Column(name="rate_of_interest")
	private final float rtf=0.4f;

	@Override
	public String toString() {
		return "Saving [rtf=" + rtf + "]";
	}

	@Override
	public float getRateofInterest() {
		return 04f;
	}
	
}
