package com.hibernate.entity;

import org.hibernate.id.IdentifierGenerator;
import java.io.Serializable;

public class Alphanumeric_Id implements IdentifierGenerator{
	@Override
    public Serializable generate(org.hibernate.engine.spi.SessionImplementor session, Object object) {
       
        Customer entity = (Customer) object;
        
        String name = entity.getName();
        
        
        String randomPart = generateRandomAlphanumeric(5);
        return name + "_" + randomPart; 
    }
	private String generateRandomAlphanumeric(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder randomString = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int randomIndex = (int) (Math.random() * characters.length());
            randomString.append(characters.charAt(randomIndex));
        }
        return randomString.toString();
    }
}
