package com.hibernate.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="account")
@Inheritance
(strategy=InheritanceType.JOINED)
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int accid;
	
	@OneToOne(mappedBy="acc",cascade=CascadeType.ALL)
	private Customer customer;
	
	public float getMonthlycharges(){
		return 0;
	}
	
	public float getRateofInterest(){
		return 0;
	}
	
	public Account() {
		super();
	}

	public int getAccid() {
		return accid;
	}

	public void setAccid(int accid) {
		this.accid = accid;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
	@Override
	public String toString() {
		return "Account [accid=" + accid + ", customer=" + customer + "]";
	}

		
}
