
        // Function to update the minimum balance message based on the selected account type
        function updateMinBalanceMessage() {
            const accountType = document.getElementById("s1").value;
            const messageDiv = document.getElementById("minBalanceMessage");
          
            let message = "";
            jointInputContainer.innerHTML= '';
            if (accountType === "Saving") {
            	message =  "Note:Minimum balance for a Saving account is 1000.";
            	
            } else if (accountType === "Joint") {
            	const label=document.createElement('label');
            	label.htmlFor='coHolderName';
            	label.textContent='Co-Holder Name:';
            	jointInputContainer.appendChild(label);
            	
            	const inputBox=document.createElement('input');
            	inputBox.name='co_name';
            	inputBox.type='text';
            	inputBox.placeholder='Enter co-holder name';
            	inputBox.id='coHolderName';
            	inputBox.required=true;
            	jointInputContainer.appendChild(inputBox);
                message = "Note:Minimum balance for a Joint account is 5000.";
                
            } else if (accountType === "Demat") {
                message = "Note:Minimum balance for a Demat account is 0.0";
               
            }

            messageDiv.textContent = message;
        }
